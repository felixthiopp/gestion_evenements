const Event = require('../models/Event');

exports.createEvent = async (req, res) => {
  try {
    const event = await Event.create({ ...req.body, user: req.user.id });
    res.status(201).json(event);
  } catch (err) {
    res.status(400).json({ error: 'Erreur création événement' });
  }
};

exports.getEvents = async (req, res) => {
  const events = await Event.find({ user: req.user.id });
  res.json(events);
};

exports.getEventById = async (req, res) => {
  const event = await Event.findOne({ _id: req.params.id, user: req.user.id });
  if (!event) return res.status(404).json({ error: 'Événement non trouvé' });
  res.json(event);
};

exports.updateEvent = async (req, res) => {
  const event = await Event.findOneAndUpdate(
    { _id: req.params.id, user: req.user.id },
    req.body,
    { new: true }
  );
  if (!event) return res.status(404).json({ error: 'Événement non trouvé' });
  res.json(event);
};

exports.deleteEvent = async (req, res) => {
  const event = await Event.findOneAndDelete({ _id: req.params.id, user: req.user.id });
  if (!event) return res.status(404).json({ error: 'Événement non trouvé' });
  res.json({ message: 'Événement supprimé' });
};
